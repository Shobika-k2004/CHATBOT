from flask import Flask, render_template, request

from langchain.llms import CTransformers
from langchain import PromptTemplate, LLMChain
from langchain.callbacks.streaming_stdout import StreamingStdOutCallbackHandler

app = Flask(__name__)

llm = CTransformers(model="TheBloke/Llama-2-7B-Chat-GGML", model_file='llama-2-7b-chat.ggmlv3.q2_K.bin', callbacks=[StreamingStdOutCallbackHandler()])

template = """
[INST] <<SYS>>
You are a helpful, respectful, and honest assistant. Your answers are always brief. and add the role as a chatbot yourself.
<</SYS>>
{text}[/INST]
"""

prompt = PromptTemplate(template=template, input_variables=["text"])
llm_chain = LLMChain(prompt=prompt, llm=llm)

@app.route('/', methods=['GET', 'POST'])
def chat():
    if request.method == 'POST':
        user_input = request.form['user_input']
        if user_input.lower() in ["quit", "exit", "bye"]:
            response = "Goodbye!"
        else:
            response = llm_chain.run(user_input)
        return render_template('app.html', user_input=user_input, response=response)
    return render_template('app.html')

if __name__ == '__main__':
    app.run(debug=True)